wget http://boobooauction.azurewebsites.net/web/app.php/auctions/update_seller
