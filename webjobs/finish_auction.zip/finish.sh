curl -s http://boobooauction.azurewebsites.net/web/app.php/finish
