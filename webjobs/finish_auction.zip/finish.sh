wget http://boobooauction.azurewebsites.net/web/app.php/auction/finish
